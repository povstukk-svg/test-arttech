import os

from dotenv import load_dotenv
from telegram import ReplyKeyboardMarkup, Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN")


def get_main_keyboard() -> ReplyKeyboardMarkup:
    """Создаёт главное меню с кнопками."""
    keyboard = [
        ["О нас", "Каталог"],
        ["Связаться", "Помощь"],
    ]

    return ReplyKeyboardMarkup(
        keyboard,
        resize_keyboard=True,
    )


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Обрабатывает команду /start."""
    user_name = update.effective_user.first_name

    text = (
        f"Здравствуйте, {user_name}! 👋\n\n"
        "Я бот ArtTech.\n"
        "Выберите нужный раздел в меню:"
    )

    await update.message.reply_text(
        text,
        reply_markup=get_main_keyboard(),
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Обрабатывает команду /help."""
    text = (
        "Я умею:\n\n"
        "• показывать информацию о компании;\n"
        "• показывать основные категории товаров;\n"
        "• выводить контактную информацию;\n"
        "• отвечать на простые сообщения.\n\n"
        "Команды:\n"
        "/start — открыть главное меню\n"
        "/help — показать помощь"
    )

    await update.message.reply_text(
        text,
        reply_markup=get_main_keyboard(),
    )


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Обрабатывает кнопки меню и обычный текст."""
    message = update.message.text

    if message == "О нас":
        text = (
            "ArtTech — магазин умной техники и аксессуаров.\n"
            "Мы предлагаем умные часы, наушники, гаджеты для дома "
            "и полезные устройства для повседневного использования."
        )

    elif message == "Каталог":
        text = (
            "Основные категории товаров:\n\n"
            "• умные часы;\n"
            "• беспроводные наушники;\n"
            "• аксессуары для смартфонов;\n"
            "• устройства для умного дома."
        )

    elif message == "Связаться":
        text = (
            "Контакты ArtTech:\n\n"
            "Telegram: @y2su\n"
            "Email: arttech@gmail.com\n"
            "Телефон: +7 707 670 67 76"
        )

    elif message == "Помощь":
        text = (
            "Выберите один из разделов меню:\n\n"
            "«О нас» — информация о компании\n"
            "«Каталог» — категории товаров\n"
            "«Связаться» — контакты"
        )

    else:
        text = (
            "Я получил ваше сообщение, но пока не могу на него ответить\n\n"
            "Пожалуйста, выберите один из пунктов меню."
        )

    await update.message.reply_text(
        text,
        reply_markup=get_main_keyboard(),
    )


def main() -> None:
    """Запускает Telegram-бота."""
    if not BOT_TOKEN:
        raise ValueError("BOT_TOKEN не найден. Добавьте токен в файл .env")

    app = ApplicationBuilder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    print("Бот запущен...")
    app.run_polling()


if __name__ == "__main__":
    main()