@echo off

echo Starting ArtTech Bot...

if not exist ".venv" (
    echo Creating virtual environment...
    py -m venv .venv
)

call .venv\Scripts\activate.bat

echo Installing dependencies...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

echo Running bot...
python bot.py

pause